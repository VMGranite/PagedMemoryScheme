/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixedpartitionsmemory;

/**
 *
 * @author veronicagranite
 */
public class Partition {
    int partitionNumber;
    int partitionSize;
    boolean freeStatus;
    String taskName;
    
    
    
    Partition(int partNumber, int partSize, boolean free){
        partitionNumber = partNumber;
        partitionSize = partSize;
        freeStatus = free; 
    }
    
    Partition(int partNumber, String name, int partSize, boolean free){
        partitionNumber = partNumber;
        taskName = name;
        partitionSize = partSize;
        freeStatus = free; 
    }
    
     public void removePartition(Partition[] partition, int index){
        partition[index] = null;
    }
    
    public void setAll(int number, int size, boolean free){
        partitionNumber = number;
        partitionSize = size;
        freeStatus = free;
    }
    
    public String getName(){
        return taskName;
    }
    
    public void setName(String name){
        taskName = name;
    }
    
    public int getSize(){
        return partitionSize;
    }
    
    public void setSize(int newSize){
        partitionSize = newSize;
    }
    
    public boolean getStatus(){
        return freeStatus;
    }
    
    public void setStatusBusy(boolean status){
        freeStatus = status;
    }
    
    public int getPartitionNumber(){
        return partitionNumber;
    }
    
}
