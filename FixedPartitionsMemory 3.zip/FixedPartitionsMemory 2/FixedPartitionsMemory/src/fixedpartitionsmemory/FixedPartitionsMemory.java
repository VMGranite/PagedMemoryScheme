/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixedpartitionsmemory;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Timer;
/**
 *
 * @author veronicagranite
 */
public class FixedPartitionsMemory {

    public static void main(String args[]) {
        System.out.println("Fixed Partitions Memory Program STARTED");
        
        //TaskList - Jobs to be done
        ArrayList<Task> taskList = new ArrayList<>();
        taskList.add(new Task("Task 1", 23, 5));
        taskList.add(new Task("Task 2", 45, 5));
        taskList.add(new Task("Task 3", 45, 5));
        taskList.add(new Task("Task 4", 90, 5));
        taskList.add(new Task("Task 5", 85, 5));
        taskList.add(new Task("Task 6", 95, 5));
        taskList.add(new Task("Task 7", 100, 5));
        taskList.add(new Task("Task 8", 25, 5));
        taskList.add(new Task("Task 9", 20, 5));

        //Free Table
        Partition[] freeList = new Partition[8];
        freeList[0] = new Partition(1,25,true);
        freeList[1] = new Partition(2,25,true);
        freeList[2] = new Partition(3,50,true);
        freeList[3] = new Partition(4,50,true);
        freeList[4] = new Partition(5,50,true);
        freeList[5] = new Partition(6,100,true);
        freeList[6] = new Partition(7,100,true);
        freeList[7] = new Partition(8,100,true);
        
        //BusyTable
        Partition[] busyList = new Partition[8];
        busyList[0] = new Partition(1, "", -1,false);
        busyList[1] = new Partition(2, "", -1,false);
        busyList[2] = new Partition(3, "", -1,false);
        busyList[3] = new Partition(4, "", -1,false);
        busyList[4] = new Partition(5, "", -1,false);
        busyList[5] = new Partition(6, "", -1,false);
        busyList[6] = new Partition(7, "", -1,false);
        busyList[7] = new Partition(8, "", -1,false);
        

        while (!taskList.isEmpty()) { 

            for(int i = 0; i < taskList.size(); i++){
                System.out.println("----------\nRecieved: " + taskList.get(i).getName());
                int freePartitionIndex = checkFreeListForSpot(taskList, taskList.get(i).getSize(), freeList);
  
                    if(freePartitionIndex != -1){ 
                       int busyListFreeIndex = findAvailableIndex(busyList, "Busy List");
                       System.out.println("Found Spot Available for Task in Free List at Index: " + freePartitionIndex);
                       moveFreeToBusy(freeList, busyList, freePartitionIndex, taskList.get(i).getName(), busyListFreeIndex);
                       removeTaskFromTaskList(taskList, i);
                       
                    }else{
                        System.out.println("No free spot found. Continuing to next task.");
                    }

        }
           
        
    }
    }


    public static int findAvailableIndex(Partition[] list, String listName){
        
         int freeIndex = -1;
                for(int a = 0; a < list.length; a++){
                    if(list[a].getSize() == -1){
                        freeIndex = a;
                        break;
                    } 
                }
                
                if(freeIndex == -1){
                    System.out.println("No Free Spot Found in " + listName + ".");
                }else{
                    System.out.println("Free Spot found in " + listName + " at index: " + freeIndex);
                }

                return freeIndex;
         
    }
    
    public static int checkFreeListForSpot(ArrayList<Task> taskList, int sizeOfTask, Partition[] freeList){
        for(int a = 0; a < freeList.length; a++){
            if((freeList[a].getStatus())&&(freeList[a].getSize() >= sizeOfTask)){
               // System.out.print(a);
                return a;
            }
        }
        
        return -1;
    }
    
    public static void moveFreeToBusy(Partition[] freeList, Partition[] busyList, int freePartitionIndex, String taskName, int busyListFreeIndex){
        
        if(busyListFreeIndex >= 0 || busyListFreeIndex <= 7){
            busyList[busyListFreeIndex].setAll(freeList[freePartitionIndex].getPartitionNumber(), freeList[freePartitionIndex].getSize(), freeList[freePartitionIndex].getStatus());
            busyList[busyListFreeIndex].setName(taskName);
            resetPartition(freeList, freePartitionIndex);
            startTaskTimer(freeList, busyList, busyListFreeIndex, freePartitionIndex);
        }else{
            System.out.println("Busy List Full");
        }   
    }
    
    public static void moveBusyToFree(Partition[] freeList, Partition[] busyList, int partitionIndex, int freeListIndex){
        
        if(freeListIndex >= 0 || freeListIndex <= 7){
            freeList[freeListIndex].setAll(busyList[partitionIndex].getPartitionNumber(), busyList[partitionIndex].getSize(), busyList[partitionIndex].getStatus());
            System.out.println("COMPLETED TASK: " + busyList[partitionIndex].getName());
            resetPartition(busyList, partitionIndex);
        }else{
            System.out.println("Free List Full");
        }
    }
    
    public static void resetPartition(Partition[] list, int index){
        list[index].setStatusBusy(false);
        list[index].setName("");
        list[index].setSize(-1);
    }

    
    public static void removeTaskFromTaskList(ArrayList<Task> taskList, int indexOfTask){
        taskList.remove(indexOfTask);
    }
    
    public static void startTaskTimer(Partition[] freeList, Partition[] busyList, int partitionIndex, int freeListIndex){
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
               moveBusyToFree(freeList, busyList, partitionIndex, freeListIndex);
            }
          }, 5000);
    }
   


    }
    
    
  
