/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixedpartitionsmemory;

/**
 *
 * @author veronicagranite
 */
class Task {
    int taskSize;
    int executionTime;
    String taskName;
    
    Task(String name, int mS, int eT) {
        taskName = name; 
        taskSize = mS;
        executionTime = eT;
    }
    
    public int getSize(){
        return taskSize;
    }
    
    public int getExecutionTime(){
        return executionTime;
    }
    
    public String getName(){
        return taskName;
    }
}
